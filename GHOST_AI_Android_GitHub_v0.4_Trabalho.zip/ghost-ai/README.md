# GHOST AI · Android (MVP 0.4 online + trabalho)

Aplicação nativa Android em Kotlin, em português de Portugal. Os comandos locais não exigem conta ou mensalidade. Para conversas com IA online, é necessária uma chave gratuita do Google AI Studio e internet.

## Princípios definidos pelo Renan

- **Gratuito:** não depender de subscrição nem de API paga para as funções básicas.
- **Pesquisa ampla:** permitir buscas abertas pela web e consultar várias fontes, com ligação à internet; pesquisar não garante a veracidade das respostas.
- **Liberdade de assuntos:** não impor filtros arbitrários para temas adultos legais, controversos ou opiniões. Preservar salvaguardas contra danos graves, abuso e atividades ilegais.
- **Privacidade:** pedir permissões de forma explícita, não guardar gravações de voz nesta versão e permitir desligar a escuta.
- **IA futura:** avaliar um modelo aberto local compatível com o hardware do Samsung ou usar um serviço gratuito com limites conhecidos. Um modelo local potente pode não caber na RAM do telemóvel, e pesquisa atualizada necessita de internet.

## Funcional nesta primeira versão

- Ecrã de assistente com comandos escritos.
- Reconhecimento de voz `pt-PT`, com "Ei Ghost" como frase de ativação enquanto a aplicação está **aberta e visível**.
- Respostas faladas por Text-to-Speech do Android.
- GPS por aplicação de navegação instalada: "Ei Ghost, GPS para Faro".
- Marcador de chamadas: "Ei Ghost, ligar para 912345678" (o utilizador confirma a chamada).
- SMS: "Ei Ghost, SMS para 912345678 dizendo vou chegar tarde" (confirmação por voz e envio manual na aplicação SMS).
- Música por aplicação compatível: "Ei Ghost, tocar música jazz".
- Alarmes: "Ei Ghost, alarme 07:30".
- Pesquisa web: "Ei Ghost, pesquisar meteorologia em Albufeira".
- Conversa com Gemini 2.5 Flash: escreve ou diz uma pergunta depois de introduzir e guardar a tua chave.
- Perguntas começadas por "pesquisar" ou "procura" usam a ferramenta Google Search da API quando disponível; sem chave, abrem a pesquisa normal do telemóvel.
- Três botões de assistência profissional: **renda extra**, **investimentos educativos com simulação** e **gestão de tráfego com campanha de exemplo**. Estes botões consultam o modelo Gemini configurado, mas ainda não ligam a bancos, corretoras ou contas publicitárias.

## Configuração gratuita da IA

1. Abre https://aistudio.google.com/apikey no navegador e entra com a tua conta Google.
2. Cria uma chave da **Gemini API** num projeto gratuito e verifica os limites aplicáveis no AI Studio.
3. No GHOST AI, cola a chave no campo "Chave gratuita do Gemini" e toca em **GUARDAR CHAVE DE IA**.
4. Faz uma pergunta, por exemplo: "Como funciona um motor de combustão?".
5. Para testar pesquisa atualizada, diz "Ei Ghost, pesquisar notícias de tecnologia de hoje".

Não é preciso ativar um plano pago para testar modelos com nível gratuito, sujeito a quotas e disponibilidade. **Não atives faturação paga** se pretendes custo zero. O fornecedor pode alterar os limites. A chave é guardada nas preferências privadas do aplicativo (não é encriptação específica com Android Keystore); é adequada a testes pessoais, não para distribuir uma chave partilhada. Não envies a chave a outras pessoas. As perguntas são transmitidas à Google e o plano gratuito pode ter tratamento de dados diferente do pago.

## Instalar

### Só com o telemóvel — GitHub Actions e Codespaces

O pacote contém `.github/workflows/build-apk.yml`: o GitHub compila automaticamente um APK de **debug/teste** após o envio dos ficheiros para a branch `main`.

1. No Chrome do Samsung, abre `https://github.com/new`, inicia sessão e cria um repositório **privado** chamado `ghost-ai-android` (podes incluir README inicial para criar a branch `main`).
2. Na página do repositório, abre **Code → Codespaces → Create codespace on main**. No Samsung, ativa "Site para computador" no Chrome se necessário. Codespaces tem disponibilidade e quota gratuita condicionadas ao plano da conta.
3. No editor do Codespace, usa o painel **Explorer → Upload…** para carregar este ZIP descarregado. Se a interface móvel não mostrar Upload, tenta o menu de contexto do Explorer.
4. Abre **Terminal → New Terminal** e executa os comandos a seguir, um de cada vez. Substitui o nome do ZIP se o descarregado tiver outro nome:

   ```bash
   unzip GHOST_AI_Android_GitHub_APK_v0.3.zip
   cp -a ghost-ai/. .
   git add .github app build.gradle.kts settings.gradle.kts gradle.properties README.md
   git commit -m "Add GHOST AI Android app and APK workflow"
   git push origin main
   ```

5. No GitHub, abre **Actions → Build GHOST AI APK**, entra na execução mais recente e aguarda o resultado verde.
6. Na secção **Artifacts**, descarrega `GHOST-AI-debug-APK`, extrai o ZIP e instala `app-debug.apk` no Samsung (o Android pode pedir autorização para instalar aplicações desta origem).
7. Se a execução ficar vermelha, copia o texto do erro e traz para esta conversa para corrigirmos. **Não é garantido que compile sem correções**, pois ainda não houve uma compilação real de validação.

> Não coloques a chave do Gemini no repositório! Introduz a chave apenas dentro da aplicação depois de instalada. Não uses o telemóvel durante a condução.

### Com computador (alternativa)

1. No computador, instala **Android Studio** e o Android SDK 35.
2. Abre a pasta `ghost-ai` com **Open**.
3. Espera pela sincronização Gradle. Se o Studio pedir JDK, escolhe o JDK 17 incorporado.
4. No Samsung, ativa **Opções de programador** e **Depuração USB**, liga o cabo e autoriza a ligação.
5. Clica **Run ▶** no Android Studio e aceita a permissão do microfone no telemóvel.
6. Testa o botão **ATIVAR 'EI GHOST'** com o ecrã aberto.

## Limitações conhecidas / próximos marcos

- **Não é um APK pronto:** este repositório contém código-fonte; precisa de compilação no Android Studio. Ainda não foi testado num Samsung físico.
- O reconhecedor de voz nativo pode parar de ouvir ao detetar silêncio; esta versão tenta reiniciar a sessão, mas não promete uma palavra-chave permanentemente ativa, offline ou fiável em ambientes ruidosos.
- Não escuta com o ecrã bloqueado ou em segundo plano. Para isso, desenhar uma solução com serviço em primeiro plano, notificação persistente e permissões adequadas; o Android 14+ impõe restrições à captação de microfone iniciada em segundo plano.
- SMS é **SMS**, não WhatsApp. Integração WhatsApp e procura de contactos ficam para fase seguinte.
- "Lembretes" por enquanto são alarmes com hora; falta calendário/persistência de tarefas.
- A conversa com IA agora usa a API Gemini quando configurada. Ainda não há memória persistente de conversas nem verificação independente da qualidade das respostas. O Google pode impor regras de utilização e segurança mesmo que o aplicativo não adicione filtros próprios.
- **Sem negociação automática ou publicidade paga automática:** a aplicação ensina, calcula exemplos e prepara campanhas, mas nunca faz transações financeiras, publica anúncios, movimenta dinheiro ou promete rendimentos. Integrações reais exigirão credenciais separadas, testes e confirmação explícita de cada ação que gaste dinheiro.
- Chamadas/mensagens nunca são enviadas diretamente pelo app. O utilizador confirma no aplicativo do sistema.
- Não operar nem configurar o telemóvel enquanto conduzes; testa os comandos com o carro parado e usa sistema mãos-livres apropriado.

## Organização

- `app/src/main/java/pt/renan/ghostai/MainActivity.kt` — UI, reconhecimento, voz, interpretações e intents.
- `app/src/main/AndroidManifest.xml` — permissão do microfone e atividade de entrada.
- `app/build.gradle.kts` — configuração Android.

## Roadmap sugerido

1. Compilar e testar num Samsung real; corrigir erros de reconhecimento e compatibilidade de intents.
2. Wake-word offline dedicado, com autorização clara, bateria e controlo de privacidade.
3. Contactos, WhatsApp e confirmações mãos-livres conforme integrações permitidas.
4. Lembretes locais, notificações, calendário e armazenamento protegido.
5. IA conversacional, opção local/remota, controlo de custos e memória configurável.
