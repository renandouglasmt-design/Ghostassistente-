package pt.renan.ghostai

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.text.InputType
import android.net.Uri
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.MediaStore
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.Normalizer
import java.util.Locale
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var listening = false
    private var autoListen = false
    private var waitingCommand = false
    private var pending: (() -> Unit)? = null
    private lateinit var status: TextView
    private lateinit var history: TextView
    private lateinit var textInput: EditText
    private lateinit var toggle: Button
    private lateinit var apiKeyInput: EditText
    private var aiBusy = false
    private val locale = Locale("pt", "PT")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(36, 45, 36, 25); setBackgroundColor(Color.rgb(9, 15, 28)) }
        fun label(value: String, size: Float): TextView = TextView(this).apply { text = value; textSize = size; setTextColor(Color.WHITE); setPadding(0, 10, 0, 12) }
        root.addView(label("◉  GHOST AI", 30f))
        root.addView(label("Assistente pessoal · versão 0.1", 15f))
        apiKeyInput = EditText(this).apply {
            hint = "Chave gratuita do Gemini (AI Studio)"
            setHintTextColor(Color.LTGRAY); setTextColor(Color.WHITE)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(getPreferences(MODE_PRIVATE).getString("gemini_key", ""))
        }
        root.addView(apiKeyInput)
        root.addView(Button(this).apply { text = "GUARDAR CHAVE DE IA"; setOnClickListener {
            getPreferences(MODE_PRIVATE).edit().putString("gemini_key", apiKeyInput.text.toString().trim()).apply()
            say("Chave guardada neste telemóvel. Já podes fazer perguntas à IA.")
        } })
        status = label("A aguardar permissão do microfone", 17f)
        root.addView(status)
        toggle = Button(this).apply { text = "ATIVAR 'EI GHOST'"; setOnClickListener { if (autoListen) stopAuto() else startAuto() } }
        root.addView(toggle)
        root.addView(label("Diz: 'Ei Ghost, abrir GPS para Faro' ou 'Ei Ghost' e depois o pedido.", 14f))
        history = label("Histórico de comandos:\n", 15f)
        root.addView(ScrollView(this).apply { addView(history); layoutParams = LinearLayout.LayoutParams(-1, 0, 1f) })
        textInput = EditText(this).apply { hint = "Ou escreve um pedido..."; setHintTextColor(Color.LTGRAY); setTextColor(Color.WHITE); inputType = 1 }
        root.addView(textInput)
        root.addView(Button(this).apply { text = "EXECUTAR COMANDO"; setOnClickListener { val command = textInput.text.toString(); textInput.setText(""); process(command) } })
        root.addView(Button(this).apply { text = "💼 IDEIAS DE RENDA EXTRA"; setOnClickListener {
            process("Cria um plano de 7 dias para eu, iniciante em Portugal, começar a ganhar renda extra online sem investimento inicial, com tarefas que posso fazer pelo telemóvel. Separa o que podes preparar do que eu devo fazer.")
        } })
        root.addView(Button(this).apply { text = "📈 INVESTIMENTOS (SIMULAÇÃO)"; setOnClickListener {
            process("Ensina-me a investir a partir de zero em Portugal. Mostra uma simulação educativa com 50 euros mensais, riscos, custos e diferenças entre poupança e investimento. Nunca executes compras nem prometas ganhos.")
        } })
        root.addView(Button(this).apply { text = "📣 GESTOR DE TRÁFEGO (PLANO)"; setOnClickListener {
            process("Age como meu professor de marketing digital. Ensina-me gestão de tráfego para iniciantes e prepara uma campanha de exemplo com público, texto de anúncio, orçamento hipotético e métricas, sem publicar nem gastar dinheiro.")
        } })
        root.addView(label("Modo voz ativo apenas com esta janela aberta. Confirma mensagens e chamadas no respetivo aplicativo.", 12f))
        setContentView(root)
        tts = TextToSpeech(this, this)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 21)
        else initRecognizer()
    }

    override fun onInit(result: Int) { if (result == TextToSpeech.SUCCESS) tts?.language = locale }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 21 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) initRecognizer()
        else status.text = "Microfone negado. Podes usar os comandos escritos."
    }
    private fun initRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { status.text = "Reconhecimento de voz indisponível neste telemóvel"; return }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { status.text = "A ouvir…" }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onError(error: Int) { listening = false; status.text = "À espera de 'Ei Ghost'…"; scheduleNext() }
            override fun onResults(results: Bundle?) {
                listening = false
                val phrase = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                onHeard(phrase)
                scheduleNext()
            }
        }) }
        status.text = "Pronto para ativar"
    }
    private fun startAuto() {
        if (recognizer == null) { status.text = "Ativa o reconhecimento de voz nas definições do Android"; return }
        autoListen = true; toggle.text = "PARAR ESCUTA"; listen()
    }
    private fun stopAuto() { autoListen = false; waitingCommand = false; toggle.text = "ATIVAR 'EI GHOST'"; recognizer?.cancel(); listening = false; status.text = "Escuta desligada" }
    private fun listen() {
        if (!autoListen || listening || isFinishing) return
        listening = true
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-PT")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        try { recognizer?.startListening(intent) } catch (_: Exception) { listening = false; status.text = "Não foi possível ouvir. Tenta novamente." }
    }
    private fun scheduleNext() { if (autoListen) status.postDelayed({ if (autoListen) listen() }, 900L) }
    private fun normal(s: String): String = Normalizer.normalize(s.lowercase(locale), Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")
    private fun onHeard(raw: String) {
        log("Tu: $raw")
        val n = normal(raw)
        val marker = Regex("(?:ei|hey|ola)\\s+ghost|\\bghost\\b").find(n)
        when {
            marker != null -> {
                val rest = raw.substring(marker.range.last + 1).trim(' ', ',', ':')
                if (rest.isEmpty()) { waitingCommand = true; say("Estou aqui, Renan. O que precisas?") }
                else { waitingCommand = false; process(rest) }
            }
            waitingCommand -> { waitingCommand = false; process(raw) }
        }
    }
    private fun log(s: String) { history.append("\n$s\n") }
    private fun say(s: String) { log("Ghost: $s"); tts?.speak(s, TextToSpeech.QUEUE_FLUSH, null, "ghost-${System.nanoTime()}") }
    private fun launch(intent: Intent, description: String) {
        try { startActivity(intent); say(description) }
        catch (_: ActivityNotFoundException) { say("Não encontrei uma aplicação compatível.") }
        catch (_: SecurityException) { say("O Android não permitiu esta ação.") }
    }
    private fun process(raw: String) {
        val cmd = normal(raw.trim())
        if (cmd.isBlank()) return
        log("Pedido: $raw")
        if (pending != null) {
            val action = pending; pending = null
            if (cmd in listOf("sim", "confirmar", "confirma", "pode", "enviar")) { action?.invoke(); return }
            if (cmd in listOf("nao", "cancelar", "cancela")) { say("Cancelado."); return }
        }
        when {
            cmd.contains("ajuda") || cmd.contains("o que podes fazer") -> say("Posso abrir rotas, chamadas, SMS, música, alarmes e pesquisas. Diz o teu pedido.")
            cmd.startsWith("ligar para ") || cmd.startsWith("chamar ") -> {
                val target = raw.substringAfter(' ').substringAfter(' ').trim()
                val number = target.filter { it.isDigit() || it == '+' }
                if (number.length < 3) say("Nesta versão, indica o número de telefone em vez do nome do contacto.")
                else { say("Vou abrir o marcador para $target. Confirma a chamada no telemóvel."); launch(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")), "Marcador aberto.") }
            }
            cmd.startsWith("sms para ") || cmd.startsWith("mensagem para ") -> {
                val match = Regex("(?:sms|mensagem) para ([+0-9 ]+?)(?: dizendo |: |, )(.*)", RegexOption.IGNORE_CASE).find(raw)
                if (match == null) say("Diz: SMS para 912345678 dizendo vou chegar mais tarde.")
                else {
                    val number = match.groupValues[1].filter { it.isDigit() || it == '+' }; val body = match.groupValues[2]
                    pending = { launch(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number")).putExtra("sms_body", body), "Mensagem preparada. Confirma o envio.") }
                    say("Mensagem para $number: $body. Dizes confirmar ou cancelar?")
                }
            }
            cmd.contains("gps") || cmd.contains("navegar para") || cmd.contains("rota para") || cmd.contains("levar-me a") || cmd.contains("levar me a") -> {
                val destination = raw.replace(Regex("(?i)^.*?(?:gps para|navegar para|rota para|levar[- ]me a)\\s*"), "").trim()
                if (destination.isBlank() || destination == raw) say("Diz: abrir GPS para Faro.")
                else launch(Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=${Uri.encode(destination)}")), "A abrir navegação para $destination.")
            }
            cmd.contains("musica") || cmd.contains("tocar ") || cmd.contains("reproduzir ") -> {
                val query = raw.replace(Regex("(?i)^(tocar|reproduzir|coloca|poe|põe)\\s*"), "").trim()
                launch(Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/audio").putExtra(android.app.SearchManager.QUERY, query), "A procurar música.")
            }
            cmd.startsWith("alarme ") || cmd.startsWith("despertador ") -> {
                val time = Regex("(\\d{1,2})[:h](\\d{2})").find(cmd)
                if (time == null) say("Diz: alarme 07:30.")
                else {
                    val hour = time.groupValues[1].toInt(); val minute = time.groupValues[2].toInt()
                    if (hour !in 0..23 || minute !in 0..59) say("Hora inválida.")
                    else launch(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, hour).putExtra(AlarmClock.EXTRA_MINUTES, minute).putExtra(AlarmClock.EXTRA_MESSAGE, "GHOST AI"), "A criar alarme para $hour e $minute.")
                }
            }
            cmd.startsWith("lembrete ") || cmd.startsWith("lembrar ") -> say("Para já consigo criar alarmes por hora. Diz, por exemplo: alarme 07:30.")
            cmd.startsWith("pesquisar ") || cmd.startsWith("procura ") || cmd.startsWith("o que e ") -> {
                val search = raw.replace(Regex("(?i)^(pesquisar|procura|o que é|o que e)\\s*"), "")
                if (getApiKey().isNotBlank()) askGemini(search, withSearch = true)
                else launch(Intent(Intent.ACTION_WEB_SEARCH).putExtra(android.app.SearchManager.QUERY, search), "Vou pesquisar isso.")
            }
            else -> if (getApiKey().isNotBlank()) askGemini(raw) else say("Para conversar com a IA, coloca a chave gratuita do Gemini no campo de cima. Também posso executar os comandos sem chave.")
        }
    }
    private fun getApiKey(): String = getPreferences(MODE_PRIVATE).getString("gemini_key", "").orEmpty()
    private fun askGemini(question: String, withSearch: Boolean = false) {
        if (aiBusy) { say("Ainda estou a responder ao pedido anterior."); return }
        val key = getApiKey()
        if (key.isBlank()) { say("Falta configurar a chave de IA."); return }
        aiBusy = true
        status.text = "A consultar IA online…"
        Thread {
            val result = try {
                val connection = (URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent").openConnection() as HttpURLConnection)
                try {
                    connection.requestMethod = "POST"; connection.connectTimeout = 15000; connection.readTimeout = 45000
                    connection.doOutput = true
                    connection.setRequestProperty("Content-Type", "application/json")
                    connection.setRequestProperty("x-goog-api-key", key)
                    val prompt = "És o GHOST AI, assistente do Renan em Portugal, iniciante em tecnologia, trabalho remoto e investimentos. Responde em português claro e natural. Ajuda-o a aprender e prepara materiais concretos: passos, textos, planos, checklists e simulações. Explica o que depende de autorização humana ou ligação a serviços externos. Nunca afirmes ter enviado mensagens, publicado anúncios, acedido a contas ou realizado investimentos se isso não ocorreu. Não prometas rentabilidade e avisa sobre risco de perda. Não inicies operações financeiras ou gastos. Respeita perguntas sobre assuntos legais e controversos, sem inventar factos. Se não souberes, admite. Mantém respostas faladas breves. Pergunta: $question"
                    val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
                    if (withSearch) body.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
                    connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                    val code = connection.responseCode
                    val response = (if (code in 200..299) connection.inputStream else connection.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
                    if (code !in 200..299) {
                        val message = try { JSONObject(response).getJSONObject("error").optString("message") } catch (_: Exception) { "Erro HTTP $code" }
                        "Não consegui consultar a IA: ${message.take(180)}"
                    } else {
                        val candidates = JSONObject(response).optJSONArray("candidates")
                        val parts = candidates?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                        (0 until (parts?.length() ?: 0)).mapNotNull { parts?.optJSONObject(it)?.optString("text") }.joinToString(" ").ifBlank { "Não encontrei resposta para esta pergunta." }
                    }
                } finally { connection.disconnect() }
            } catch (_: Exception) { "Não consegui ligar à IA. Confirma a internet e a chave ou tenta novamente." }
            runOnUiThread {
                aiBusy = false
                status.text = if (autoListen) "À espera de 'Ei Ghost'…" else "Pronto"
                say(result.take(1200))
            }
        }.start()
    }
    override fun onPause() { super.onPause(); if (autoListen) stopAuto() }
    override fun onDestroy() { stopAuto(); recognizer?.destroy(); tts?.stop(); tts?.shutdown(); super.onDestroy() }
}
