plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android {
    namespace = "pt.renan.ghostai"
    compileSdk = 35
    defaultConfig { applicationId = "pt.renan.ghostai"; minSdk = 26; targetSdk = 35; versionCode = 4; versionName = "0.4" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
